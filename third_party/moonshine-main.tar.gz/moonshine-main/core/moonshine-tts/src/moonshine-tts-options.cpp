#include "moonshine-tts-options.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <string_view>

#include "g2p-path.h"
#include "ort-model-format.h"
#include "ort-utils.h"
#include "string-utils.h"

namespace moonshine_tts {

void apply_synthesis_output_effects(std::vector<float>& audio,
                                    bool normalize_audio, float volume) {
  if (normalize_audio) {
    float max_val = 0.F;
    for (float x : audio) {
      max_val = std::max(max_val, std::fabs(x));
    }
    if (max_val < 1e-8F) {
      std::fill(audio.begin(), audio.end(), 0.F);
    } else {
      const float inv = 1.F / max_val;
      for (float& x : audio) {
        x *= inv;
      }
    }
  }
  if (volume != 1.F) {
    for (float& x : audio) {
      x *= volume;
    }
  }
  for (float& x : audio) {
    x = std::max(-1.F, std::min(1.F, x));
  }
}

MoonshineTTSOptions::MoonshineTTSOptions() {
  files.set_path(kTtsKokoroModelKey, std::filesystem::path{kTtsKokoroModelKey});
  files.set_path(kTtsKokoroConfigJsonKey,
                 std::filesystem::path{kTtsKokoroConfigJsonKey});
}

void MoonshineTTSOptions::apply_voice_engine_prefix() {
  voice = trim(voice);
  if (voice.empty()) {
    return;
  }
  const std::string low = to_lowercase(voice);
  static constexpr std::string_view k_k = "kokoro_";
  static constexpr std::string_view k_p = "piper_";
  static constexpr std::string_view k_z = "zipvoice_";
  static constexpr std::string_view k_ph = "phonon_";
  if (low.size() >= k_k.size() && low.compare(0, k_k.size(), k_k) == 0) {
    vocoder_engine = "kokoro";
    voice = trim(voice.substr(k_k.size()));
  } else if (low.size() >= k_p.size() && low.compare(0, k_p.size(), k_p) == 0) {
    vocoder_engine = "piper";
    voice = trim(voice.substr(k_p.size()));
  } else if (low.size() >= k_z.size() && low.compare(0, k_z.size(), k_z) == 0) {
    vocoder_engine = "zipvoice";
    voice = trim(voice.substr(k_z.size()));
  } else if (low == "zipvoice") {
    // Bare engine selector with no built-in id: caller supplies a clone
    // reference clip.
    vocoder_engine = "zipvoice";
    voice.clear();
  } else if (low.size() >= k_ph.size() &&
             low.compare(0, k_ph.size(), k_ph) == 0) {
    vocoder_engine = "phonon";
    voice = trim(voice.substr(k_ph.size()));
  } else if (low == "phonon") {
    // Bare engine selector: the caller supplies a voice file.
    vocoder_engine = "phonon";
    voice.clear();
  }
}

std::filesystem::path MoonshineTTSOptions::tts_relative_path(
    std::string_view canonical_key) const {
  const std::string k(canonical_key);
  const auto it = files.entries.find(k);
  if (it == files.entries.end()) {
    return std::filesystem::path(canonical_key);
  }
  return it->second.path;
}

void MoonshineTTSOptions::parse_options(
    const std::vector<std::pair<std::string, std::string>>& options,
    std::string* cli_language, bool* language_was_set) {
  std::vector<std::pair<std::string, std::string>> g2p_pairs;
  g2p_pairs.reserve(options.size());

  for (const auto& entry : options) {
    const std::string& name = entry.first;
    const std::string& value = entry.second;
    const std::string key = replace_all(to_lowercase(name), "-", "_");

    if (key == "tts_root" || key == "path_root" || key == "model_root") {
      const std::string t = trim(value);
      if (!t.empty()) {
        g2p_options.g2p_root = std::filesystem::path(t);
      }
    } else if (key == "g2p_root") {
      g2p_options.g2p_root = std::filesystem::path(trim(value));
    } else if (key == "use_bundled_cpp_g2p_data" || key == "bundle_g2p_data") {
      // Deprecated: cwd-based asset discovery was removed; value ignored.
    } else if (key == "lang" || key == "language") {
      if (!cli_language) {
        throw std::runtime_error("MoonshineTTSOptions: option \"" + name +
                                 "\" is invalid without a language output "
                                 "pointer; use parse_options(options, &lang, "
                                 "&lang_set) or pass the language to "
                                 "MoonshineTTS(language, options).");
      }
      *cli_language = trim(value);
      if (language_was_set) {
        *language_was_set = true;
      }
    } else if (key == "voice") {
      voice = trim(value);
    } else if (key == "speed") {
      speed = static_cast<double>(float_from_string(value.c_str()));
    } else if (key == "kokoro_dir") {
      const std::string t = trim(value);
      if (!t.empty()) {
        const std::filesystem::path d(t);
        files.set_path(kTtsKokoroModelKey, ort_model_path(d, "model.ort"));
        files.set_path(kTtsKokoroConfigJsonKey, d / "config.json");
      }
    } else if (key == "kokoro_model" || key == "kokoro_model_onnx") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsKokoroModelKey));
      } else {
        files.set_path(kTtsKokoroModelKey, std::filesystem::path(t));
      }
    } else if (key == "kokoro_config" || key == "kokoro_config_json") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsKokoroConfigJsonKey));
      } else {
        files.set_path(kTtsKokoroConfigJsonKey, std::filesystem::path(t));
      }
    } else if (key == "piper_onnx" || key == "piper_model_onnx" ||
               key == "piper_model") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsPiperOnnxKey));
      } else {
        const std::filesystem::path model(t);
        require_ort_model_path(model, "Piper model given as " + key);
        files.set_path(kTtsPiperOnnxKey, model);
      }
    } else if (key == "piper_onnx_json" || key == "piper_model_json" ||
               key == "piper_onnx_config") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsPiperOnnxJsonKey));
      } else {
        files.set_path(kTtsPiperOnnxJsonKey, std::filesystem::path(t));
      }
    } else if (key == "piper_voices_dir" || key == "voices_dir") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsPiperVoicesKey));
      } else {
        files.set_path(kTtsPiperVoicesKey, std::filesystem::path(t));
      }
    } else if (key == "piper_voices_json_dir" || key == "voices_json_dir") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsPiperVoicesJsonKey));
      } else {
        files.set_path(kTtsPiperVoicesJsonKey, std::filesystem::path(t));
      }
    } else if (key == "engine" || key == "vocoder_engine") {
      // Deprecated: vocoder is selected via voice prefix (kokoro_* / piper_*).
      // Ignored for compatibility.
      (void)value;
    } else if (key == "output" || key == "o") {
      output_path = std::filesystem::path(trim(value));
    } else if (key == "normalize_audio" || key == "piper_normalize_audio") {
      normalize_audio = bool_from_string(value.c_str());
    } else if (key == "output_volume" || key == "piper_output_volume") {
      output_volume = float_from_string(value.c_str());
    } else if (key == "piper_noise_scale" ||
               key == "piper_noise_scale_override") {
      const std::string t = trim(value);
      piper_noise_scale_override =
          t.empty() ? std::nullopt
                    : std::optional<float>(float_from_string(t.c_str()));
    } else if (key == "piper_noise_w" || key == "piper_noise_w_override") {
      const std::string t = trim(value);
      piper_noise_w_override =
          t.empty() ? std::nullopt
                    : std::optional<float>(float_from_string(t.c_str()));
    } else if (key == "zipvoice_clone_transcript" ||
               key == "clone_transcript") {
      zipvoice_clone_transcript = value;
    } else if (key == "zipvoice_clone_sample_rate" ||
               key == "clone_sample_rate") {
      const std::string t = trim(value);
      if (!t.empty()) {
        zipvoice_clone_sample_rate =
            static_cast<int>(float_from_string(t.c_str()));
      }
    } else if (key == "zipvoice_model" || key == "zipvoice_model_name") {
      // ``zipvoice`` (full) vs ``zipvoice_distill`` (default). Only changes
      // sampling defaults.
      zipvoice_distill = (trim(to_lowercase(value)) != "zipvoice");
    } else if (key == "zipvoice_distill") {
      zipvoice_distill = bool_from_string(value.c_str());
    } else if (key == "zipvoice_num_step" || key == "num_step") {
      const std::string t = trim(value);
      if (!t.empty()) {
        zipvoice_num_step = static_cast<int>(float_from_string(t.c_str()));
      }
    } else if (key == "zipvoice_guidance_scale" || key == "guidance_scale") {
      const std::string t = trim(value);
      if (!t.empty()) {
        zipvoice_guidance_scale = float_from_string(t.c_str());
      }
    } else if (key == "zipvoice_t_shift" || key == "t_shift") {
      const std::string t = trim(value);
      if (!t.empty()) {
        zipvoice_t_shift = float_from_string(t.c_str());
      }
    } else if (key == "phonon_temperature" || key == "temperature") {
      const std::string t = trim(value);
      if (!t.empty()) {
        phonon_temperature = float_from_string(t.c_str());
      }
    } else if (key == "phonon_duration_delta" || key == "duration_delta") {
      const std::string t = trim(value);
      phonon_duration_delta =
          t.empty() ? std::nullopt
                    : std::optional<float>(float_from_string(t.c_str()));
    } else if (key == "phonon_seed" || key == "seed") {
      const std::string t = trim(value);
      if (!t.empty()) {
        phonon_seed = static_cast<unsigned int>(std::stoul(t));
      }
    } else if (key == "phonon_normalize_text") {
      phonon_normalize_text = bool_from_string(value.c_str());
    } else if (key == "phonon_voice_file" || key == "phonon_voice") {
      const std::string t = trim(value);
      if (t.empty()) {
        files.erase_key(std::string(kTtsPhononVoiceFileKey));
      } else {
        files.set_path(kTtsPhononVoiceFileKey, std::filesystem::path(t));
      }
    } else if (key == "log_profiling") {
      log_profiling = bool_from_string(value.c_str());
    } else if (key == "ort_providers" || key == "ort_provider") {
      ort_provider_names = ort_parse_provider_names(trim(value));
    } else if (key == "coreml_cache_dir") {
      coreml_cache_dir = trim(value);
    } else {
      g2p_pairs.push_back(entry);
    }
  }

  g2p_options.parse_options(g2p_pairs);
  apply_voice_engine_prefix();
}

}  // namespace moonshine_tts
